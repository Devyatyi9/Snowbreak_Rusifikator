﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snowbreak_Rusifikator
{
    public static class ProgramVariables
    {
        //GitHub
        public const string gitHubRepoLink = "https://api.github.com/repos/Devyatyi9/Snowbreak_RU_translation/contents/";
        public const string gitHubToken = "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";
        public const string gitHubTesterBranch = "?ref=test"; //public static string mainBranch = "?ref=main";
        //GitLab
        public const string gitLabRepoLink = "";
        public const string gitLabToken = "";
        public const string gitLabTesterBranch = "?ref=test";
    }
}
