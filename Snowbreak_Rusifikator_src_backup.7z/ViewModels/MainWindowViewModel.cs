﻿using Avalonia.Platform.Storage;
using ReactiveUI;
using Avalonia.Controls;
using System.Diagnostics;
using System.Reactive;
using System;

namespace Snowbreak_Rusifikator.ViewModels;

public class MainWindowViewModel : ViewModelBase
{
    public IObservable<bool> isInputValid;
    private string _userName = string.Empty;

    public string UserName
    {
        get { return _userName; }
        set { this.RaiseAndSetIfChanged(ref _userName, value); }
    }

    public ReactiveCommand<Unit, Unit> SubmitCommand { get; }

    //IObservable<bool> isInputValid;
    //IObservable<bool> isInputValid = this.WhenAnyValue(
    //            x => x.UserName,
    //            x => !string.IsNullOrWhiteSpace(x) && x.Length > 7
    //            );

    public MainWindowViewModel()
    {
        var isValidInput = this.
            WhenAnyValue(
                    x => x.UserName,
                    x => !string.IsNullOrWhiteSpace(x) && x.Length > 7
                    ).Subscribe();
        SubmitCommand = ReactiveCommand.Create(() =>
        {
            Debug.WriteLine("The submit command was run.");
        }, isInputValid);   
    }

    //
    public void SelectPathButton() 
    {
        //var topLevel = TopLevel.GetTopLevel(this);

        //IStorageProvider storage = topLevel.StorageProvider;
        //await Models.MainModel.SelectGameFlder(storage);
    }


#pragma warning disable CA1822 // Mark members as static

#pragma warning restore CA1822 // Mark members as static
    //Models.MainModel MainModel { get; set; }
}
