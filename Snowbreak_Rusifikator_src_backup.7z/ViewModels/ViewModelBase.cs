﻿using ReactiveUI;

namespace Snowbreak_Rusifikator.ViewModels;

public class ViewModelBase : ReactiveObject
{
}
